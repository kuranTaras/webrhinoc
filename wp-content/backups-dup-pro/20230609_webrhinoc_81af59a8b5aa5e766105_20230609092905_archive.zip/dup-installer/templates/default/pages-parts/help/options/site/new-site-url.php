<?php

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">New Site URL</td>
    <td>
        The New Site URL input field is auto filled with the installation site URL. By default you have no need to change it.
    </td>
</tr>