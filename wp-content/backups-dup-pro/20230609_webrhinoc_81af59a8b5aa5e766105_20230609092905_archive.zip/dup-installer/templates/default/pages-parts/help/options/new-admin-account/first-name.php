<?php

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">First Name</td>
    <td>First name of the user being created. Optional.</td>
</tr>