<?php

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Update</td>
    <td>
        Indicates the table will be processed for URL replacement as well as custom search and replace. 
        Turn off this switch to prevent the replacement processing.
        Option is on by default.
    </td>
</tr>