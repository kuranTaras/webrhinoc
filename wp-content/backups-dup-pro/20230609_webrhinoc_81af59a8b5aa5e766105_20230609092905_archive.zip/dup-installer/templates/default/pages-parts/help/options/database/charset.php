<?php

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Charset</td>
    <td>When the database is populated from the SQL script it will use this value as part of its connection.  Only change this value if you know what your
        databases character set should be.</td>
</tr>