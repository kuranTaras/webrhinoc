<?php

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Keep Users</td>
    <td>
        This option is enabled when you are overwriting an existing site. 
        This option allows you to keep all users of the existing site and remove all users of package created site. 
        If you wish to transfer all users of the original site, Select the "- DISABLED -" option. The "- DISABLED -" option is selected by default. 
        All pages and posts will be assigned to the selected user.
    </td>
</tr>