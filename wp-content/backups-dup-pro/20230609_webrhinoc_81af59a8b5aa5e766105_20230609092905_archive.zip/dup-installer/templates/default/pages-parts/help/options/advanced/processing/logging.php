<?php

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Logging</td>
    <td>
        The level of detail that will be sent to the log file (installer-log.txt).  The recommend setting for most installs should be 'Light'. 
        Note if you use Debug the amount of data written can be very large.  Debug is only recommended for support.
    </td>
</tr>