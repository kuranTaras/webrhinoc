<?php

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Site Title</td>
    <td>
        Title of the installed site. The title is typically the name of your site.
    </td>
</tr>