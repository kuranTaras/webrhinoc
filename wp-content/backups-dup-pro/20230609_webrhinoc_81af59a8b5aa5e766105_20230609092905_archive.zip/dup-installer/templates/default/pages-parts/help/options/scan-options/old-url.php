<?php

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Old URL</td>
    <td>The old URL of the original values that the package was created with.  These values should not be changed, unless you know the underlying reasons</td>
</tr>